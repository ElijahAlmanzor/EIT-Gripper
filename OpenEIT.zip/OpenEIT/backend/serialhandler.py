"""

# Copyright (c) Mindseye Biomedical LLC. All rights reserved.
# Distributed under the (new) CC BY-NC-SA 4.0 License. See LICENSE.txt for more info.

"""
# Serial handler class.
from __future__ import absolute_import
from sys import platform
import time
import threading
import logging
import serial
import serial.threaded
import uuid

import os 

import numpy as np
import scipy.io

if platform == "linux" or platform == "linux2":
    # linux
    from OpenEIT.backend.bluetooth import Adafruit_BluefruitLE
    from OpenEIT.backend.bluetooth.Adafruit_BluefruitLE.services import UART
elif platform == "darwin_xx":
    # OS X
    import objc
    from PyObjCTools import AppHelper    
    from OpenEIT.backend.bluetooth import Adafruit_BluefruitLE
    from OpenEIT.backend.bluetooth.Adafruit_BluefruitLE.services import UART
elif platform == "win32":
    print ('windows users')

# Define service and characteristic UUIDs used by the UART service.
UART_SERVICE_UUID = uuid.UUID('6E400001-B5A3-F393-E0A9-E50E24DCCA9E')
TX_CHAR_UUID      = uuid.UUID('6E400002-B5A3-F393-E0A9-E50E24DCCA9E')
RX_CHAR_UUID      = uuid.UUID('6E400003-B5A3-F393-E0A9-E50E24DCCA9E')

logger = logging.getLogger(__name__)


def parse_any_line(line, mode):  

    items = []
    if 'a' in mode:
        for item in line.split(","):
            item = item.strip()
            if not item:
                continue
            try:
                items.append(float(item))
            except ValueError:
                return None
    elif 'b' in mode:
        try:  
            _, data = line.split(":", 1)
        except ValueError:
            return None

        for item in data.split(";"):
            item = item.strip()
            if not item:
                continue
            try:
                items.append(float(item))
            except ValueError:
                return None
    else:
        try:  
            _, data = line.split(":", 1)
        except ValueError:
            return None

        for item in data.split(","):
            item = item.strip()
            if not item:
                continue
            try:
                items.append(float(item))
            except ValueError:
                return None

    return items


class SerialHandler:

    def __init__(self, queue):
        self._connection_lock = threading.Lock()
        self._reader_thread = None
        self._queue = queue
        #self._mpqueue = Queue()
        self._recording_lock = threading.Lock()
        self._recording = False
        self._record_file = None
        self._bytestream = ''
        # self._data_type = data_type
        self._mode = 'd' # mode

        self.raw_text = 'what the duck is this'
         
        self.ble_line = ''
        self.get_line_lock = 0 
        self.device = ''
        self.stoprequest = threading.Event()

    def is_connected(self):
        with self._connection_lock:
            return self._reader_thread is not None

    def return_last_line(self):
        with self._connection_lock:
            return self.raw_text

    # this needs updating to have a bluetooth method separate from the reader_thread serial method. 
    def disconnect(self):
        with self._connection_lock:
            if self._reader_thread is None:
                return

            self._reader_thread.close()
            self._reader_thread = None

    def write(self, text):
        self._reader_thread.write(text.encode())

    def setmode(self, mode):
        self._mode = mode

    def getmode(self):
        return self._mode

    def getbytes(self):
        return self._bytestream

    


    def connect(self, port_selection):
        with self._connection_lock:
            if self._reader_thread is not None:
                raise RuntimeError("serial already connected")

            print('connecting to: ', port_selection)

           
            # configure the serial connection
            ser = serial.Serial()
            ser.port = port_selection
            ser.baudrate =  115200
            ser.bytesize = serial.EIGHTBITS
            ser.parity = serial.PARITY_NONE
            ser.stopbits = serial.STOPBITS_ONE
            ser.timeout = None
            ser.xonxoff = False
            ser.rtscts = False
            ser.dsrdtr = False
            ser.writeTimeout = 1#2

            try:
                ser.open()
                # on connect, write the mode from the config file. 
                #encodes mode d to the device
                ser.write(self._mode.encode())
                #print ('writing mode to device')

            except serial.SerialException:
                print ('Could not connect')
                logger.error('Cannot connect to %s', port_selection)
                raise

            serialhandler = self

            class LineReader(serial.threaded.LineReader):
                
                TERMINATOR = b'\n'

                def connection_made(self, transport):
                    serialhandler._connected = True
                    super().connection_made(transport)
                    logger.info('connection made ')

                def handle_line(self, line):
                    #print("hi")
                    # XXX: we should not record the raw stream but the
                    # parsed data
                    # print (line)
                    serialhandler.raw_text = line
                    
                    with serialhandler._recording_lock:
                        if serialhandler._recording:
                            logger.info("serialhandler._recording")
                            # serialhandler._record_file.write(line + "\n")
                            serialhandler._bytestream = serialhandler._bytestream + line
                    
                    res = parse_any_line(line,serialhandler._mode)
                    
                    a = 2
                    #print(res) #matrix of raw values
                    mode = str(serialhandler.getmode())
                    #print(type(mode), mode)
                    '''if len(res) < 35:
                        print("lol why is it not printing?")
                        #values_matrix = np.asarray(res)
                        #print(values_matrix)
                        #scipy.io.savemat('arrdata.mat', mdict={'arr': values_matrix})'''


                    if res is not None:
                        serialhandler._queue.put(res)

                        if len(res) < 35:
                            print(res)
                            values_matrix = np.asarray(res)
                            scipy.io.savemat('./arrdata.mat', mdict={'arr': values_matrix})

                def connection_lost(self, exc):
                    if exc is not None:
                        logger.error('connection lost %s', str(exc))
                    else:
                        logger.info('connection lost')

                    with serialhandler._connection_lock:
                        if serialhandler._reader_thread is self:
                            serialhandler._reader_thread = None

                

           
            self._reader_thread = serial.threaded.ReaderThread(
                ser,
                LineReader
            )

            # start the reader thread
            self._reader_thread.start()
            self._reader_thread.connect()
            

            


    @property
    def recording(self):
        with self._recording_lock:
            return self._recording

    def start_recording(self):
        with self._recording_lock:
            print('recording started!!')
            timestr = time.strftime("%Y%m%d-%H%M%S")
            self._recording = True
            # self._record_file = open('data_' + timestr + '.txt', 'a')
            self._bytestream = '' 

    def stop_recording(self):
        with self._recording_lock:
            print('recording stopped')
            self._recording = False
            # self._record_file.close()
