"""
backend provides the dashboard with raw data to process.
"""

from .serialhandler import SerialHandler #, parse_line
