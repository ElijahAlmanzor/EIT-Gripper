"""
pyEIT : Python based Electrical Impedance Tomography

eit:
    reconstruction algorithms
mesh:
    create triangle(2D) / tetrahedron(3D) meshes
"""
